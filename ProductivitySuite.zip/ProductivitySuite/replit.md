# ENVOY - Secure Data Request Portal

## Overview
ENVOY is a zen-inspired, production-ready web portal that allows government authorities to submit data access requests to private companies. The application features a calm, minimalist interface with soft colors, generous whitespace, and smooth animations designed to reduce friction in typically stressful legal compliance processes.

## Branding
- **Name**: ENVOY
- **Tagline**: Secure Data Request Portal
- **Logo**: Minimalist geometric design combining shield and data flow lines in soft sage/teal color
- **Concept**: Official messenger/representative for government data requests

## Purpose
Enable government authorities to:
- Submit formal data access requests with legal documentation
- Upload supporting files (court orders, e-evidence directives)
- Track request deadlines based on EU e-Evidence Directive timelines

Enable administrators to:
- View all submitted requests in a clean dashboard
- Monitor deadline countdowns with color-coded urgency
- Mark requests as completed
- Download attached legal documentation

## Design Philosophy
**Calm Japanese Minimalism meets Secure European Compliance**
- Soft sage/teal primary colors (#69B7AC)
- Generous whitespace and breathing room
- Rounded corners with rounded-xl styling (never sharp edges)
- Smooth Framer Motion animations
- Inter font for clean, professional typography
- JetBrains Mono (monospaced) for dates, technical information, and statistics
- Design system adherence (no hardcoded colors)

## Tech Stack
- **Frontend**: React SPA with TypeScript
- **Styling**: TailwindCSS with custom design tokens
- **Animations**: Framer Motion for smooth transitions
- **Forms**: React Hook Form with Zod validation
- **State**: TanStack Query for server state
- **Backend**: Express.js
- **Database**: PostgreSQL with Drizzle ORM
- **Auth**: Replit Auth (OpenID Connect)
- **File Upload**: Multer for multipart form handling

## Application Structure

### Pages
1. **Landing Page** (`/`) - Logged out users
   - ENVOY logo and branding
   - Welcome message explaining the portal
   - Feature highlights (Security, Easy Submission, Timeline Tracking)
   - Login button for admin access

2. **Request Form** (`/request`) - Public and authenticated access
   - ENVOY logo and branding
   - Instructional text box with guidelines
   - Comprehensive form with ALL MANDATORY fields (marked with *):
     - Product name *
     - Company name *
     - Institution name *
     - Contact person (first/last name *, email *, phone *)
     - Reason for data request *
     - Time limit (Normal - 10 days / Urgent - 8 hours) *
     - Other channels used to request information *
     - Customer notification preference (Inform / Do not inform) *
     - Reason for not informing customer *
     - Preferred data handover method (Secure Email, SFTP, API Access, etc.) *
   - File upload with drag-and-drop support (at least one file required)
   - Client-side validation with inline error messages
   - Success confirmation with animation

3. **Admin Dashboard** (`/`) - Authenticated users only
   - Header with ENVOY logo and user information
   - Statistics cards (Total, Pending, Completed, Declined) with monospaced bold font
   - Filter buttons (All, Pending, Completed, Declined, Urgent)
   - Request cards in responsive grid layout (clickable to view details)
   - Each card shows:
     - Institution name and contact details
     - Product name and company name
     - Time limit badge (Normal/Urgent) with pulsing urgency indicator
     - Customer notification preference
     - Data handover method (if specified)
     - Date received with countdown timer
     - Status badge (Pending/Completed)
     - Attachments with download links
     - Action buttons:
       - "Ask for Legal Advice" (blue button, pending requests)
       - "Mark as Completed" (pending requests)
       - "Decline Request" (orange button, pending requests)
       - "Reopen Request" (completed/declined requests)
   - Requests are sorted by status (pending → completed → declined), then within pending by traffic light urgency (red → yellow → green), then by date received

4. **Request Details Page** (`/request/:id`) - Authenticated users only
   - Header with ENVOY logo, request ID, and back navigation
   - Two-column layout:
     - **Left Column**: Request information cards
       - Status and timeline card with request metadata
       - Request details card with reason, channels, notification preferences
       - Attached documents grid/table with:
         - Document name
         - File type (PDF, DOC, Image, etc.)
         - File size
         - Download action button
     - **Right Column**: Action sidebar with two sections
       - **Actions Card** (status-dependent):
         - When status is pending: "Mark Complete" and "Decline Request" buttons with loading state
         - When status is completed or declined: "Reopen Request" button with loading state
         - Decline button uses orange styling (bg-orange-600 hover:bg-orange-700)
         - Modern rounded-xl styling
         - Contextual informational text
       - **Internal Notes Card**:
         - Add note form with textarea and submit button
         - Notes list showing all notes for the request
         - Each note displays:
           - User initials in circular badge
           - Timestamp (MMM dd, yyyy at HH:mm)
           - Note content
         - Notes ordered newest first
         - Empty state when no notes exist
   - Error handling for unauthorized access, not found, and server errors
   - Client-side navigation for smooth SPA experience

### Database Schema

**users** - Replit Auth user data
- id (UUID, primary key)
- email
- firstName, lastName
- profileImageUrl
- createdAt, updatedAt

**sessions** - Session storage for Replit Auth
- sid (primary key)
- sess (JSONB)
- expire

**dataRequests** - Data access requests
- id (UUID, primary key)
- productName
- companyName
- institutionName
- contactFirstName, contactLastName
- contactEmail, contactPhone
- reasonForRequest
- otherChannels
- reasonNotInformingCustomer
- dataHandoverMethod (Secure Email, SFTP, API Access, Encrypted USB, Secure Portal, Other)
- informCustomer (inform/do-not-inform)
- timeLimitType (normal/urgent)
- status (pending/completed/declined)
- dateReceived
- completedAt (timestamp when marked complete, null when reopened)
- createdAt, updatedAt

**fileAttachments** - Uploaded legal documents
- id (UUID, primary key)
- requestId (foreign key to dataRequests)
- fileName (stored filename)
- originalName (user's filename)
- mimeType
- fileSize
- filePath
- createdAt

**internalNotes** - Admin notes for requests
- id (UUID, primary key)
- requestId (foreign key to dataRequests)
- userId (foreign key to users)
- userInitials (auto-generated from user's name)
- content (note text)
- createdAt

## Features Implemented

### Frontend
✅ Zen-inspired design with soft colors and generous spacing
✅ Smooth Framer Motion animations throughout
✅ Fully responsive design (mobile, tablet, desktop)
✅ **All form fields are mandatory** with client-side validation
✅ **Required field indicators (*) on all form labels**
✅ Form validation with inline error messages
✅ File upload with drag-and-drop support
✅ Real-time deadline countdown timers (updates every 30 seconds)
✅ Traffic light urgency indicators (green/yellow/red pulsing dots)
✅ Filter buttons: All, Pending, Completed, Declined, Urgent
✅ Complete/decline/reopen request workflow with status tracking
✅ Data handover method selection and display
✅ Beautiful loading and success states
✅ Accessible keyboard navigation and ARIA labels
✅ Internal notes system for admin collaboration
✅ **Modern button styling with rounded-xl design**
✅ **Status-dependent action buttons** (Mark Complete/Reopen)
✅ **Monospaced bold font for statistics** (font-mono font-semibold)
✅ Request form accessible to both authenticated and unauthenticated users
✅ **Smart sorting: Red urgent requests (critical traffic lights) appear first**
✅ **Decline request functionality with orange button styling**
✅ **Three-state request workflow: pending → completed/declined → reopen**

### Backend
✅ Replit Auth integration for admin access
✅ PostgreSQL database with Drizzle ORM
✅ File upload handling with Multer
✅ Request CRUD operations
✅ Status update endpoints with completedAt tracking
✅ Reopen functionality (unmark completed requests)
✅ File download endpoints
✅ Input validation with Zod schemas
✅ Error handling and proper HTTP status codes
✅ Internal notes CRUD with automatic user initials generation
✅ Robust user upsert logic handling email uniqueness

## API Endpoints

### Public Endpoints
- `POST /api/requests` - Submit new data access request with files
- `GET /api/files/:id` - Download file attachment

### Protected Endpoints (Admin Only)
- `GET /api/auth/user` - Get current authenticated user
- `GET /api/requests` - Get all requests with attachments
- `PATCH /api/requests/:id/status` - Update request status
- `GET /api/requests/:id/notes` - Get all notes for a request
- `POST /api/requests/:id/notes` - Add a new note to a request

### Auth Endpoints
- `GET /api/login` - Initiate Replit Auth login flow
- `GET /api/logout` - Logout and end session
- `GET /api/callback` - OAuth callback handler

## Environment Variables
- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Session encryption secret
- `REPLIT_DOMAINS` - Comma-separated list of allowed domains
- `REPL_ID` - Replit application ID
- `ISSUER_URL` - OIDC issuer URL (optional, defaults to Replit)

## File Storage
Uploaded files are stored in `/uploads` directory with unique filenames to prevent conflicts. Original filenames are preserved in the database for display purposes.

## Color Scheme

### Light Mode
- Background: #FAFAFA (soft off-white)
- Card: #FFFFFF (pure white)
- Primary: #69B7AC (soft sage/teal)
- Text: Warm dark gray (#3D3D3D)
- Muted: Medium gray (#737373)

### Dark Mode
- Background: #1A1D23 (warm dark)
- Card: #24272E (slightly lighter)
- Primary: #73C4B8 (brighter sage)
- Text: Light gray (#EBEBEB)

## Deployment Notes
1. Database is automatically provisioned via PostgreSQL integration
2. Run `npm run db:push` to sync database schema
3. Seed data can be added for demo purposes
4. File upload directory is created automatically on first upload
5. Sessions are stored in PostgreSQL for reliability

## Future Enhancements
- Email notifications to admins on new submissions
- Request filtering by date range
- Advanced search functionality
- Bulk status updates
- Request assignment to specific admin users
- PDF report generation
- Analytics dashboard
