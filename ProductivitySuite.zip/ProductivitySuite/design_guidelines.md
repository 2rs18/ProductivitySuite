# Design Guidelines: Data Access Request Portal

## Design Approach

**Selected Approach:** Custom Zen-Inspired Aesthetic (User-Specified)
The design follows "calm Japanese minimalism meets secure European compliance" - a unique blend of serene aesthetics with professional credibility. This creates trust while reducing anxiety around legal/compliance processes.

## Core Design Principles

1. **Tranquility First:** Every element should feel calm and reassuring
2. **Clarity Through Space:** Generous whitespace guides attention naturally
3. **Smooth Continuity:** All transitions flow like water, never jarring
4. **Professional Trust:** Zen aesthetic balanced with institutional credibility

## Color Palette

**Primary Colors (Light Mode):**
- Background: 0 0% 98% (soft off-white with warmth)
- Surface: 0 0% 100% (pure white for cards/forms)
- Primary Brand: 180 25% 65% (soft sage/teal - calming, trustworthy)
- Primary Hover: 180 30% 55%

**Secondary/Accent:**
- Secondary: 210 20% 70% (muted blue-gray for supporting elements)
- Accent Warm: 30 35% 75% (soft peach for subtle highlights - use sparingly)
- Text Primary: 220 15% 25% (warm dark gray, never pure black)
- Text Secondary: 220 10% 50% (medium gray)

**Status Colors (Desaturated for Zen Feel):**
- Pending: 45 40% 70% (soft amber)
- Completed: 140 30% 65% (muted sage green)
- Urgent: 10 35% 70% (soft coral, not alarming)

**Dark Mode:**
- Background: 220 15% 12%
- Surface: 220 12% 18%
- Primary: 180 30% 60%
- Text Primary: 0 0% 92%

## Typography

**Font Families:**
- Headings: Inter (400, 500, 600 weights) - modern, clean, professional
- Body: Inter (400, 500 weights) - consistency throughout
- Monospace: JetBrains Mono (for dates, IDs) - 400 weight

**Scale (Desktop):**
- Hero/Page Title: text-4xl (2.25rem), font-medium, tracking-tight
- Section Headers: text-2xl (1.5rem), font-medium
- Card Titles: text-lg (1.125rem), font-medium
- Body: text-base (1rem), font-normal
- Small/Meta: text-sm (0.875rem), text-secondary

**Line Heights:** Generous - leading-relaxed (1.625) for body, leading-tight (1.25) for headings

## Layout System

**Spacing Primitives:** Use Tailwind units of 4, 6, 8, 12, 16, 24 for consistency
- Component padding: p-6, p-8
- Section spacing: space-y-8, space-y-12
- Card gaps: gap-6
- Form field spacing: space-y-6

**Container Widths:**
- Max content width: max-w-4xl (forms, content)
- Admin dashboard: max-w-7xl (data tables need more room)
- Centered: mx-auto with px-6 for mobile breathing room

**Grid Usage:**
- Admin cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Form layout: Single column for clarity
- Dashboard stats: grid-cols-2 md:grid-cols-4

## Component Library

**Cards/Surfaces:**
- Background: white/surface color
- Border: border border-gray-200 (very subtle, nearly invisible)
- Rounded: rounded-2xl (generous, soft corners - never sharp)
- Shadow: shadow-sm on cards, shadow-md on forms (very subtle)
- Padding: p-8 for forms, p-6 for cards
- Hover: Gentle lift with shadow-lg transition

**Buttons:**
- Primary: bg-primary, rounded-full (pill shape), px-8 py-3
- Text: text-white, font-medium
- Hover: Scale to 102%, subtle shadow increase
- Secondary: bg-white border-2 border-primary, text-primary
- Disabled: Reduced opacity, cursor-not-allowed

**Form Elements:**
- Inputs: rounded-xl, border-gray-200, focus:border-primary, focus:ring-4 focus:ring-primary/10
- Height: py-3 px-4 (generous touch targets)
- Labels: text-sm font-medium text-gray-700, mb-2
- Placeholders: text-gray-400 (soft, not harsh)
- File upload: Dashed border, rounded-xl, p-8, hover state with bg-gray-50

**Admin Dashboard Elements:**
- Status badges: rounded-full, px-4 py-1.5, text-sm, font-medium
- Countdown timers: Monospace font, color-coded (green > 7 days, amber 3-7, coral < 3)
- Action buttons: Icon + text, rounded-lg, hover:bg-gray-50
- Table alternative: Card-based layout for mobile-friendliness

**Instructional Text Box:**
- Background: gradient from primary/5 to secondary/5
- Border: border-l-4 border-primary
- Padding: p-6
- Icon: Soft information icon in primary color
- Text: text-gray-600, leading-relaxed

## Animations & Transitions

**Philosophy:** All motion should feel natural and purposeful, never sudden

**Transitions:**
- Standard: transition-all duration-300 ease-in-out
- Hover effects: duration-200
- Page transitions: Gentle fade-in (opacity 0 to 1) over 400ms

**Framer Motion Specifications:**
- Form submission: Success checkmark animates in with spring physics
- Card entry: Stagger children by 100ms, fade + slide up 20px
- Admin requests: Fade between pending/completed states
- File upload: Gentle pulse on drag-over state
- NO aggressive animations - everything subtle and calming

## Page-Specific Design

**Public Form Page:**
- Top: Logo (max-w-48, centered, mb-12)
- Instructional box: Full width, mb-8
- Form: White card, shadow-md, max-w-2xl centered
- Submit button: Full width on mobile, auto width on desktop (float right)
- Background: Subtle gradient from bg to bg-secondary/10

**Admin Dashboard:**
- Header: Logo + "Admin Dashboard" + logout button
- Stats cards: 4-column grid showing total requests, pending, completed, urgent
- Request cards: Masonry or grid layout, NOT a table
- Each card shows: Org name (large), contact, deadline countdown (prominent), status badge, action buttons
- Filter buttons: Soft pill buttons (All, Pending, Completed) above cards

## Images

**Logo Placement:**
- Position: Top center of page
- Size: h-16 to h-20
- Margin: mb-12 for breathing room
- Style: Should work on both light backgrounds (consider adding subtle shadow if needed)

**No hero images needed** - this is a utility application where clarity trumps visual drama. The zen aesthetic is achieved through color, space, and typography, not imagery.

## Accessibility

- Focus states: 4px ring in primary/40, rounded to match element
- Color contrast: All text meets WCAG AA (4.5:1 minimum)
- Touch targets: Minimum 44x44px for all interactive elements
- Form validation: Inline errors below fields, red-50 background, red-600 text
- Screen reader labels on all form fields and interactive elements
- Keyboard navigation: Logical tab order, visible focus indicators

## Dark Mode Consistency

- Maintain same spacing and layout
- Invert surface/background relationship
- Reduce shadow intensity
- Keep primary color vibrant but slightly desaturated
- Form inputs: bg-surface with lighter border

This design creates a professional yet calming experience that reduces friction in a typically stressful compliance process.