import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import {
  ArrowLeft,
  FileText,
  Download,
  CheckCircle2,
  XCircle,
  Clock,
  Building2,
  Mail,
  Phone,
  User,
  MapPin,
  FileCheck,
  AlertCircle,
  RefreshCw,
  StickyNote,
  Send,
} from "lucide-react";
import type { DataRequest, FileAttachment, InternalNote } from "@shared/schema";
import { formatDistanceToNow, format } from "date-fns";
import logoImage from "@assets/generated_images/ENVOY_icon_geometric_symbol_ca9e6061.png";
import { apiRequest, queryClient } from "@/lib/queryClient";

type RequestWithAttachments = DataRequest & {
  attachments: FileAttachment[];
};

export default function RequestDetails() {
  const { toast } = useToast();
  const { user, isLoading: authLoading } = useAuth();
  const [match, params] = useRoute("/request/:id");
  const [, setLocation] = useLocation();
  const requestId = params?.id;
  const [newNote, setNewNote] = useState("");

  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [user, authLoading, toast]);

  const { data: requests, isLoading, error } = useQuery<RequestWithAttachments[]>({
    queryKey: ["/api/requests"],
    enabled: !!user,
  });

  // Fetch notes for this request
  const { data: notes = [] } = useQuery<InternalNote[]>({
    queryKey: ["/api/requests", requestId, "notes"],
    enabled: !!user && !!requestId,
  });

  // Mutation for updating request status
  const updateStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      return await apiRequest("PATCH", `/api/requests/${requestId}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests"] });
      toast({
        title: "Status Updated",
        description: "Request status has been updated successfully.",
      });
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update request status.",
        variant: "destructive",
      });
    },
  });

  // Mutation for adding a new note
  const addNoteMutation = useMutation({
    mutationFn: async (content: string) => {
      return await apiRequest("POST", `/api/requests/${requestId}/notes`, { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests", requestId, "notes"] });
      setNewNote("");
      toast({
        title: "Note Added",
        description: "Your note has been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add note. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAddNote = () => {
    if (!newNote.trim()) {
      toast({
        title: "Empty Note",
        description: "Please enter some text before adding a note.",
        variant: "destructive",
      });
      return;
    }
    addNoteMutation.mutate(newNote);
  };

  // Handle query errors
  useEffect(() => {
    if (error) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Session Expired",
          description: "Your session has expired. Please log in again.",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      } else {
        toast({
          title: "Error Loading Request",
          description: "Failed to load request details. Please try again.",
          variant: "destructive",
        });
      }
    }
  }, [error, toast]);

  const request = requests?.find((r) => r.id === requestId);

  const getFileTypeFromMime = (mimeType: string): string => {
    if (mimeType.includes("pdf")) return "PDF";
    if (mimeType.includes("word") || mimeType.includes("document")) return "DOC";
    if (mimeType.includes("image")) return "Image";
    return "File";
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + " KB";
    return (bytes / (1024 * 1024)).toFixed(2) + " MB";
  };

  if (authLoading || isLoading || !user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-secondary/10 flex items-center justify-center">
        <div className="text-center">
          <div className="h-12 w-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading request details...</p>
        </div>
      </div>
    );
  }

  // Show error state if query failed
  if (error && !isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-secondary/10 flex items-center justify-center px-6">
        <div className="text-center max-w-md">
          <AlertCircle className="h-16 w-16 text-destructive mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-foreground mb-2">Error Loading Request</h2>
          <p className="text-muted-foreground mb-6">
            {isUnauthorizedError(error)
              ? "Your session has expired. Please log in again."
              : "Failed to load request details. This could be a temporary server issue."}
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button onClick={() => setLocation("/")} data-testid="button-back-to-dashboard">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
            {!isUnauthorizedError(error) && (
              <Button
                variant="outline"
                onClick={() => window.location.reload()}
                data-testid="button-retry"
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Retry
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Show not found state if request doesn't exist
  if (!match || (!isLoading && !request)) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-secondary/10 flex items-center justify-center px-6">
        <div className="text-center">
          <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-foreground mb-2">Request Not Found</h2>
          <p className="text-muted-foreground mb-6">The requested data access request could not be found.</p>
          <Button onClick={() => setLocation("/")} data-testid="button-back-to-dashboard">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  // Type guard to ensure request is defined
  if (!request) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/10">
      {/* Header */}
      <div className="bg-card border-b border-card-border">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img src={logoImage} alt="ENVOY" className="h-10 w-10 object-contain rounded-full" />
            <div>
              <h1 className="text-xl font-bold text-foreground">Request Details</h1>
              <p className="text-sm text-muted-foreground">ID: {request.id}</p>
            </div>
          </div>
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            data-testid="button-back"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Request Information */}
          <div className="lg:col-span-2 space-y-6">
            {/* Status and Timeline */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-foreground mb-2">{request.institutionName}</h2>
                    <div className="flex items-center gap-3">
                      <Badge
                        variant={request.status === "completed" ? "default" : request.status === "declined" ? "destructive" : "secondary"}
                        className={request.status === "declined" ? "bg-orange-600 hover:bg-orange-700 border-orange-700" : ""}
                        data-testid={`badge-status-${request.status}`}
                      >
                        {request.status === "completed" ? (
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                        ) : request.status === "declined" ? (
                          <XCircle className="h-3 w-3 mr-1" />
                        ) : (
                          <Clock className="h-3 w-3 mr-1" />
                        )}
                        {request.status === "completed" ? "Completed" : request.status === "declined" ? "Declined" : "Pending"}
                      </Badge>
                      <Badge
                        variant={request.timeLimitType === "urgent" ? "destructive" : "outline"}
                        data-testid={`badge-time-limit-${request.timeLimitType}`}
                      >
                        {request.timeLimitType === "urgent" ? "Urgent - 8 hours" : "Normal - 10 days"}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground mb-1">Received</p>
                    <p className="text-sm font-medium text-foreground">
                      {formatDistanceToNow(new Date(request.dateReceived), { addSuffix: true })}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <Building2 className="h-5 w-5 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-sm text-muted-foreground">Product</p>
                        <p className="text-sm font-medium text-foreground">{request.productName}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <MapPin className="h-5 w-5 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-sm text-muted-foreground">Company Name</p>
                        <p className="text-sm font-medium text-foreground">{request.companyName}</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <User className="h-5 w-5 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-sm text-muted-foreground">Contact Person</p>
                        <p className="text-sm font-medium text-foreground">
                          {request.contactFirstName} {request.contactLastName}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Mail className="h-5 w-5 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-sm text-muted-foreground">Email</p>
                        <p className="text-sm font-medium text-foreground">{request.contactEmail}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Phone className="h-5 w-5 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-sm text-muted-foreground">Phone</p>
                        <p className="text-sm font-medium text-foreground">{request.contactPhone}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>

            {/* Request Details */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-4">Request Details</h3>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-semibold text-foreground mb-1">Reason for Request</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{request.reasonForRequest}</p>
                  </div>
                  {request.otherChannels && (
                    <div>
                      <p className="text-sm font-semibold text-foreground mb-1">Other Channels Used</p>
                      <p className="text-sm text-muted-foreground leading-relaxed">{request.otherChannels}</p>
                    </div>
                  )}
                  <div>
                    <p className="text-sm font-semibold text-foreground mb-1">Customer Notification</p>
                    <Badge variant={request.informCustomer === "inform" ? "default" : "secondary"}>
                      {request.informCustomer === "inform" ? "Inform Customer" : "Do Not Inform Customer"}
                    </Badge>
                  </div>
                  {request.reasonNotInformingCustomer && (
                    <div>
                      <p className="text-sm font-semibold text-foreground mb-1">Reason for Not Informing</p>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {request.reasonNotInformingCustomer}
                      </p>
                    </div>
                  )}
                  {request.dataHandoverMethod && (
                    <div>
                      <p className="text-sm font-semibold text-foreground mb-1">Preferred Handover Method</p>
                      <p className="text-sm text-muted-foreground">{request.dataHandoverMethod}</p>
                    </div>
                  )}
                </div>
              </Card>
            </motion.div>

            {/* Attached Documents Grid */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="p-6">
                <div className="flex items-center gap-2 mb-6">
                  <FileCheck className="h-5 w-5 text-primary" />
                  <h3 className="text-lg font-semibold text-foreground">
                    Attached Documents ({request.attachments.length})
                  </h3>
                </div>

                {request.attachments.length === 0 ? (
                  <div className="text-center py-12">
                    <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                    <p className="text-muted-foreground">No documents attached to this request</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3 px-4 text-sm font-semibold text-foreground">Document Name</th>
                          <th className="text-left py-3 px-4 text-sm font-semibold text-foreground">File Type</th>
                          <th className="text-left py-3 px-4 text-sm font-semibold text-foreground">File Size</th>
                          <th className="text-right py-3 px-4 text-sm font-semibold text-foreground">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {request.attachments.map((attachment, index) => (
                          <tr
                            key={attachment.id}
                            className="border-b border-border/50 hover:bg-secondary/20 transition-colors"
                            data-testid={`document-row-${index}`}
                          >
                            <td className="py-4 px-4">
                              <div className="flex items-center gap-3">
                                <div className="h-10 w-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                                  <FileText className="h-5 w-5 text-primary" />
                                </div>
                                <div>
                                  <p className="text-sm font-medium text-foreground" data-testid={`document-name-${index}`}>
                                    {attachment.originalName}
                                  </p>
                                </div>
                              </div>
                            </td>
                            <td className="py-4 px-4">
                              <Badge variant="outline" data-testid={`document-type-${index}`}>
                                {getFileTypeFromMime(attachment.mimeType)}
                              </Badge>
                            </td>
                            <td className="py-4 px-4">
                              <p className="text-sm text-muted-foreground" data-testid={`document-size-${index}`}>
                                {formatFileSize(attachment.fileSize)}
                              </p>
                            </td>
                            <td className="py-4 px-4 text-right">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => window.open(`/api/files/${attachment.id}`, '_blank')}
                                data-testid={`button-download-${index}`}
                              >
                                <Download className="h-4 w-4 mr-2" />
                                Download
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </Card>
            </motion.div>
          </div>

          {/* Right Column - Actions and Notes */}
          <div className="lg:col-span-1 space-y-6">
            {/* Actions Card */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-6">Actions</h3>
                
                {request.status === "pending" && (
                  <div className="space-y-3">
                    <Button
                      onClick={() => updateStatusMutation.mutate("completed")}
                      disabled={updateStatusMutation.isPending}
                      className="w-full rounded-xl"
                      size="lg"
                      data-testid="button-complete"
                    >
                      <CheckCircle2 className="h-5 w-5 mr-2" />
                      {updateStatusMutation.isPending ? "Updating..." : "Mark Complete"}
                    </Button>
                    <Button
                      onClick={() => updateStatusMutation.mutate("declined")}
                      disabled={updateStatusMutation.isPending}
                      className="w-full rounded-xl bg-orange-600 hover:bg-orange-700 text-white border-orange-700"
                      size="lg"
                      data-testid="button-decline"
                    >
                      <XCircle className="h-5 w-5 mr-2" />
                      {updateStatusMutation.isPending ? "Updating..." : "Decline Request"}
                    </Button>
                    <div className="pt-3 border-t border-border">
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Mark the request as completed or decline it if it cannot be fulfilled.
                      </p>
                    </div>
                  </div>
                )}

                {(request.status === "completed" || request.status === "declined") && (
                  <div className="space-y-3">
                    <Button
                      onClick={() => updateStatusMutation.mutate("pending")}
                      disabled={updateStatusMutation.isPending}
                      variant="outline"
                      className="w-full rounded-xl"
                      size="lg"
                      data-testid="button-reopen"
                    >
                      <RefreshCw className="h-5 w-5 mr-2" />
                      {updateStatusMutation.isPending ? "Updating..." : "Reopen Request"}
                    </Button>
                    <div className="pt-3 border-t border-border">
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        This will reopen the request and mark it as pending in the dashboard.
                      </p>
                    </div>
                  </div>
                )}
              </Card>
            </motion.div>

            {/* Internal Notes Card */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Card className="p-6">
                <div className="flex items-center gap-2 mb-6">
                  <StickyNote className="h-5 w-5 text-primary" />
                  <h3 className="text-lg font-semibold text-foreground">Internal Notes</h3>
                </div>

                {/* Add Note Form */}
                <div className="space-y-3 mb-6">
                  <Textarea
                    placeholder="Add a note about this request..."
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    className="min-h-[100px] resize-none"
                    data-testid="input-note"
                  />
                  <Button
                    onClick={handleAddNote}
                    disabled={!newNote.trim() || addNoteMutation.isPending}
                    className="w-full"
                    data-testid="button-add-note"
                  >
                    <Send className="h-4 w-4 mr-2" />
                    {addNoteMutation.isPending ? "Adding..." : "Add Note"}
                  </Button>
                </div>

                {/* Notes List */}
                <div className="space-y-4">
                  {notes.length === 0 ? (
                    <div className="text-center py-8">
                      <StickyNote className="h-10 w-10 text-muted-foreground mx-auto mb-3 opacity-50" />
                      <p className="text-sm text-muted-foreground">No notes yet</p>
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-[500px] overflow-y-auto">
                      {notes.map((note) => (
                        <div
                          key={note.id}
                          className="bg-secondary/30 rounded-lg p-4 border border-border"
                          data-testid={`note-${note.id}`}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                                <span className="text-xs font-bold text-primary">
                                  {note.userInitials}
                                </span>
                              </div>
                              <span className="text-xs text-muted-foreground font-mono">
                                {format(new Date(note.createdAt), "MMM dd, yyyy 'at' HH:mm")}
                              </span>
                            </div>
                          </div>
                          <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap">
                            {note.content}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
