import { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { Upload, FileText, X, CheckCircle2, Info, Shield, FileCheck, ArrowLeft } from "lucide-react";
import logoImage from "@assets/generated_images/ENVOY_icon_geometric_symbol_ca9e6061.png";

const formSchema = z.object({
  productName: z.string().min(1, "Product name is required"),
  companyName: z.string().min(1, "Company name is required"),
  institutionName: z.string().min(1, "Institution name is required"),
  contactFirstName: z.string().min(1, "First name is required"),
  contactLastName: z.string().min(1, "Last name is required"),
  contactEmail: z.string().email("Valid email is required"),
  contactPhone: z.string().min(1, "Phone number is required"),
  reasonForRequest: z.string().min(1, "Reason for request is required"),
  otherChannels: z.string().min(1, "Other channels information is required"),
  reasonNotInformingCustomer: z.string().min(1, "Reason for not informing customer is required"),
  dataHandoverMethod: z.string().min(1, "Data handover method is required"),
  informCustomer: z.string().min(1, "Please select whether to inform the customer"),
  timeLimitType: z.string().min(1, "Please select a time limit"),
});

type FormData = z.infer<typeof formSchema>;

const countries = [
  "United States", "United Kingdom", "Germany", "France", "Spain", "Italy", 
  "Netherlands", "Belgium", "Sweden", "Denmark", "Norway", "Finland",
  "Austria", "Switzerland", "Poland", "Portugal", "Greece", "Ireland",
  "Czech Republic", "Hungary", "Romania", "Other"
];

export default function RequestForm() {
  const [files, setFiles] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      productName: "",
      companyName: "",
      institutionName: "",
      contactFirstName: "",
      contactLastName: "",
      contactEmail: "",
      contactPhone: "",
      reasonForRequest: "",
      otherChannels: "",
      reasonNotInformingCustomer: "",
      dataHandoverMethod: "",
      informCustomer: "",
      timeLimitType: "",
    },
  });

  const submitMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const formData = new FormData();
      formData.append("data", JSON.stringify(data));
      files.forEach((file) => {
        formData.append("files", file);
      });

      const response = await fetch("/api/requests", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Failed to submit request");
      }

      return response.json();
    },
    onSuccess: () => {
      setSubmitted(true);
      form.reset();
      setFiles([]);
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    if (files.length === 0) {
      toast({
        title: "Missing Documents",
        description: "Please upload at least one legal document.",
        variant: "destructive",
      });
      return;
    }
    submitMutation.mutate(data);
  };

  const handleFileSelect = (selectedFiles: FileList | null) => {
    if (selectedFiles) {
      const newFiles = Array.from(selectedFiles);
      
      // Check file size (max 10MB per file)
      const oversizedFiles = newFiles.filter(file => file.size > 10 * 1024 * 1024);
      if (oversizedFiles.length > 0) {
        toast({
          title: "File Too Large",
          description: "Maximum file size is 10MB per file.",
          variant: "destructive",
        });
        return;
      }
      
      setFiles((prev) => [...prev, ...newFiles]);
    }
  };

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileSelect(e.dataTransfer.files);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-primary/5 flex items-center justify-center px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl w-full text-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="relative mb-8 mx-auto w-32 h-32"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-primary/10 rounded-full blur-2xl"></div>
            <div className="relative h-32 w-32 bg-card rounded-full flex items-center justify-center border-2 border-primary/20 shadow-xl">
              <CheckCircle2 className="h-16 w-16 text-primary" />
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold text-foreground mb-4">Request Submitted Successfully</h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-8 max-w-md mx-auto">
              Your data access request has been received and is being processed. You will receive a confirmation email shortly with your request details.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={() => setSubmitted(false)}
                size="lg"
                className="rounded-full"
                data-testid="button-submit-another"
              >
                Submit Another Request
              </Button>
              <Button
                onClick={() => window.location.href = "/"}
                size="lg"
                variant="outline"
                className="rounded-full"
              >
                Return Home
              </Button>
            </div>
          </motion.div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-primary/5">
      {/* Hero Header */}
      <div className="bg-gradient-to-br from-primary/20 via-primary/10 to-transparent border-b border-border/50 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-6 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center space-y-6"
          >
            <div className="flex items-center justify-center gap-3 mb-6">
              <img src={logoImage} alt="ENVOY" className="h-16 w-16 object-contain rounded-full" />
              <span className="text-3xl font-bold text-foreground tracking-tight">ENVOY</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold text-foreground leading-tight max-w-3xl mx-auto">
              Data Access Request
            </h1>
            
            <p className="text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              Submit secure, compliant data requests with complete documentation and transparent processing.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-8 pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 bg-primary/10 rounded-full flex items-center justify-center">
                  <Shield className="h-5 w-5 text-primary" />
                </div>
                <span className="text-sm font-medium text-foreground">Secure & Encrypted</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 bg-primary/10 rounded-full flex items-center justify-center">
                  <FileCheck className="h-5 w-5 text-primary" />
                </div>
                <span className="text-sm font-medium text-foreground">EU Compliant</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Form Section */}
      <div className="max-w-4xl mx-auto px-6 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Button
            variant="ghost"
            onClick={() => window.location.href = "/"}
            className="mb-8 rounded-full"
            data-testid="button-back"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>

          <div className="bg-card/80 backdrop-blur-sm rounded-3xl p-8 md:p-12 shadow-xl border border-card-border">
            <div className="mb-10">
              <h2 className="text-3xl font-bold text-foreground mb-3">Request Information</h2>
              <p className="text-muted-foreground leading-relaxed">
                Please provide complete and accurate information to ensure timely processing of your data access request.
              </p>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                {/* Section: Basic Information */}
                <div className="space-y-6">
                  <div className="border-l-4 border-primary pl-4">
                    <h3 className="text-lg font-semibold text-foreground mb-1">Basic Information</h3>
                    <p className="text-sm text-muted-foreground">Primary details about your request</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="productName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-semibold text-foreground">
                            Product Name <span className="text-destructive">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="Enter product name"
                              className="rounded-xl"
                              data-testid="input-product-name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="companyName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-semibold text-foreground">
                            Company Name <span className="text-destructive">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="Enter company name"
                              className="rounded-xl"
                              data-testid="input-company-name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="institutionName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-semibold text-foreground">
                          Institution Requesting Data <span className="text-destructive">*</span>
                        </FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder="Enter institution name"
                            className="rounded-xl"
                            data-testid="input-institution"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Section: Legal Documentation */}
                <div className="space-y-6">
                  <div className="border-l-4 border-primary pl-4">
                    <h3 className="text-lg font-semibold text-foreground mb-1">Legal Documentation</h3>
                    <p className="text-sm text-muted-foreground">Upload documents proving request legitimacy</p>
                  </div>

                  <div className="space-y-4">
                    <label className="text-sm font-semibold text-foreground block">
                      Supporting Legal Documents <span className="text-destructive">*</span>
                    </label>
                    
                    <div
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      className={`border-2 border-dashed rounded-2xl p-8 transition-all duration-200 ${
                        isDragging
                          ? "border-primary bg-primary/10 scale-[1.02]"
                          : "border-border hover:border-primary/50 hover:bg-primary/5"
                      }`}
                    >
                      <input
                        type="file"
                        multiple
                        onChange={(e) => handleFileSelect(e.target.files)}
                        className="hidden"
                        id="file-upload"
                        accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                        data-testid="input-file-upload"
                      />
                      <label
                        htmlFor="file-upload"
                        className="flex flex-col items-center gap-4 cursor-pointer"
                      >
                        <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center">
                          <Upload className="h-8 w-8 text-primary" />
                        </div>
                        <div className="text-center">
                          <p className="text-base font-semibold text-foreground mb-1">
                            Click to upload or drag and drop
                          </p>
                          <p className="text-sm text-muted-foreground">
                            PDF, DOC, DOCX, JPG, PNG (Max 10MB per file)
                          </p>
                        </div>
                      </label>
                    </div>

                    {files.length > 0 && (
                      <div className="space-y-3">
                        {files.map((file, index) => (
                          <motion.div
                            key={index}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 20 }}
                            className="flex items-center justify-between bg-secondary/20 rounded-xl p-4 border border-border/50"
                          >
                            <div className="flex items-center gap-4">
                              <div className="h-10 w-10 bg-primary/10 rounded-lg flex items-center justify-center">
                                <FileText className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <p className="text-sm font-medium text-foreground">{file.name}</p>
                                <p className="text-xs text-muted-foreground">
                                  {(file.size / 1024 / 1024).toFixed(2)} MB
                                </p>
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => removeFile(index)}
                              className="h-8 w-8 rounded-full bg-secondary/50 hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-all flex items-center justify-center"
                              data-testid={`button-remove-file-${index}`}
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </motion.div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Section: Contact Information */}
                <div className="space-y-6">
                  <div className="border-l-4 border-primary pl-4">
                    <h3 className="text-lg font-semibold text-foreground mb-1">Contact Information</h3>
                    <p className="text-sm text-muted-foreground">Primary point of contact for this request</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="contactFirstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-semibold text-foreground">
                            First Name <span className="text-destructive">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="Enter first name"
                              className="rounded-xl"
                              data-testid="input-contact-first-name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="contactLastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-semibold text-foreground">
                            Last Name <span className="text-destructive">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="Enter last name"
                              className="rounded-xl"
                              data-testid="input-contact-last-name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="contactEmail"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-semibold text-foreground">
                            Email Address <span className="text-destructive">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              type="email"
                              placeholder="email@institution.gov"
                              className="rounded-xl"
                              data-testid="input-contact-email"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="contactPhone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-semibold text-foreground">
                            Phone Number <span className="text-destructive">*</span>
                          </FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              type="tel"
                              placeholder="+1 (555) 000-0000"
                              className="rounded-xl"
                              data-testid="input-contact-phone"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* Section: Request Details */}
                <div className="space-y-6">
                  <div className="border-l-4 border-primary pl-4">
                    <h3 className="text-lg font-semibold text-foreground mb-1">Request Details</h3>
                    <p className="text-sm text-muted-foreground">Specifics about your data access request</p>
                  </div>

                  <FormField
                    control={form.control}
                    name="reasonForRequest"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-semibold text-foreground">
                          Reason for Data Request <span className="text-destructive">*</span>
                        </FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            placeholder="Provide a detailed explanation of why this data is being requested..."
                            rows={5}
                            className="rounded-xl resize-none"
                            data-testid="input-reason"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="timeLimitType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-semibold text-foreground">
                            Request Time Limit <span className="text-destructive">*</span>
                          </FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="rounded-xl" data-testid="select-time-limit">
                                <SelectValue placeholder="Select time limit" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="normal">Normal - 10 days</SelectItem>
                              <SelectItem value="urgent">Urgent - 8 hours</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="dataHandoverMethod"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-semibold text-foreground">
                            Preferred Handover Method <span className="text-destructive">*</span>
                          </FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="rounded-xl" data-testid="select-handover-method">
                                <SelectValue placeholder="Select handover method" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="secure-email">Secure Email</SelectItem>
                              <SelectItem value="sftp">SFTP (Secure File Transfer Protocol)</SelectItem>
                              <SelectItem value="api">API Access</SelectItem>
                              <SelectItem value="encrypted-usb">Encrypted USB Drive</SelectItem>
                              <SelectItem value="secure-portal">Secure Web Portal</SelectItem>
                              <SelectItem value="other">Other (specify in comments)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="otherChannels"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-semibold text-foreground">
                          Other Channels Used for Information Request <span className="text-destructive">*</span>
                        </FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            placeholder="List any other communication channels used (email, phone, portal, etc.)"
                            rows={3}
                            className="rounded-xl resize-none"
                            data-testid="input-other-channels"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Section: Customer Notification */}
                <div className="space-y-6">
                  <div className="border-l-4 border-primary pl-4">
                    <h3 className="text-lg font-semibold text-foreground mb-1">Customer Notification</h3>
                    <p className="text-sm text-muted-foreground">Customer communication preferences</p>
                  </div>

                  <div className="bg-primary/5 border border-primary/20 rounded-2xl p-6">
                    <div className="flex items-start gap-4">
                      <div className="h-10 w-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                        <Info className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-foreground mb-2">Important Legal Notice</p>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          ENVOY will inform the customer to the full extent allowed by local national law as it applies to the type of request. Please specify your preference below.
                        </p>
                      </div>
                    </div>
                  </div>

                  <FormField
                    control={form.control}
                    name="informCustomer"
                    render={({ field }) => (
                      <FormItem className="space-y-4">
                        <FormLabel className="text-sm font-semibold text-foreground">
                          Customer Notification Preference <span className="text-destructive">*</span>
                        </FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="space-y-3"
                          >
                            <div className="flex items-center space-x-3 bg-secondary/20 rounded-xl p-4 border border-border/50 hover:bg-secondary/30 transition-colors">
                              <RadioGroupItem value="inform" id="inform" data-testid="radio-inform-customer" />
                              <label
                                htmlFor="inform"
                                className="text-sm font-medium cursor-pointer leading-relaxed flex-1"
                              >
                                Inform the customer(s) about this data request
                              </label>
                            </div>
                            <div className="flex items-center space-x-3 bg-secondary/20 rounded-xl p-4 border border-border/50 hover:bg-secondary/30 transition-colors">
                              <RadioGroupItem value="do-not-inform" id="do-not-inform" data-testid="radio-do-not-inform-customer" />
                              <label
                                htmlFor="do-not-inform"
                                className="text-sm font-medium cursor-pointer leading-relaxed flex-1"
                              >
                                Do not inform the customer(s) about this data request
                              </label>
                            </div>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="reasonNotInformingCustomer"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-semibold text-foreground">
                          Reason(s) for Not Informing Customer <span className="text-destructive">*</span>
                        </FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            placeholder="If you selected 'Do not inform', please provide legal justification. If you selected 'Inform', you may enter 'N/A' or a brief note."
                            rows={4}
                            className="rounded-xl resize-none"
                            data-testid="input-reason-not-informing"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Submit Button */}
                <div className="pt-6 border-t border-border">
                  <Button
                    type="submit"
                    size="lg"
                    disabled={submitMutation.isPending}
                    className="w-full rounded-xl text-base font-semibold"
                    data-testid="button-submit-request"
                  >
                    {submitMutation.isPending ? (
                      <>
                        <div className="h-5 w-5 border-2 border-background border-t-transparent rounded-full animate-spin mr-2"></div>
                        Submitting Request...
                      </>
                    ) : (
                      "Submit Data Access Request"
                    )}
                  </Button>
                  <p className="text-sm text-muted-foreground text-center mt-4">
                    By submitting, you confirm all information is accurate and complete
                  </p>
                </div>
              </form>
            </Form>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
