import { useEffect, useState, forwardRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  FileText,
  Clock,
  CheckCircle2,
  LogOut,
  Filter,
  Download,
  Scale,
  RotateCcw,
  XCircle,
} from "lucide-react";
import type { DataRequest, FileAttachment } from "@shared/schema";
import { formatDistanceToNow, isPast, differenceInDays } from "date-fns";
import logoImage from "@assets/generated_images/ENVOY_icon_geometric_symbol_ca9e6061.png";

type RequestWithAttachments = DataRequest & {
  attachments: FileAttachment[];
};

type FilterType = "all" | "pending" | "completed" | "declined" | "urgent";

export default function AdminDashboard() {
  const { toast } = useToast();
  const { user, isLoading: authLoading } = useAuth();
  const [filter, setFilter] = useState<FilterType>("all");
  const [, setTick] = useState(0);

  // Force re-render every 30 seconds to update countdowns in real-time
  useEffect(() => {
    const interval = setInterval(() => {
      setTick(prev => prev + 1);
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [user, authLoading, toast]);

  const { data: requests, isLoading } = useQuery<RequestWithAttachments[]>({
    queryKey: ["/api/requests"],
    enabled: !!user,
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      return await apiRequest("PATCH", `/api/requests/${id}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests"] });
      toast({
        title: "Status Updated",
        description: "Request status has been updated successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update request status.",
        variant: "destructive",
      });
    },
  });

  // Helper function to get traffic light urgency level (red=0, yellow=1, green=2, none=3)
  const getUrgencyLevel = (request: RequestWithAttachments): number => {
    if (request.status === "completed" || request.status === "declined") return 3; // No urgency for completed/declined
    
    const now = new Date();
    const receivedDate = new Date(request.dateReceived);
    
    if (request.timeLimitType === "urgent") {
      const hoursElapsed = (now.getTime() - receivedDate.getTime()) / (1000 * 60 * 60);
      const hoursRemaining = 8 - hoursElapsed;
      if (hoursRemaining < 3) return 0; // RED zone
      if (hoursRemaining < 6) return 1; // YELLOW zone
      return 2; // GREEN zone
    } else {
      const daysElapsed = differenceInDays(now, receivedDate);
      const daysRemaining = 10 - daysElapsed;
      if (daysRemaining < 3) return 0; // RED zone
      if (daysRemaining < 6) return 1; // YELLOW zone
      return 2; // GREEN zone
    }
  };

  // Helper function to check if a request has red urgency indicator
  const isRedUrgent = (request: RequestWithAttachments) => {
    return getUrgencyLevel(request) === 0;
  };

  const filteredRequests = requests
    ?.filter((request) => {
      if (filter === "all") return true;
      if (filter === "urgent") return request.timeLimitType === "urgent" && request.status === "pending";
      return request.status === filter;
    })
    .sort((a, b) => {
      // PRIORITY 1: Sort by status - pending first, completed middle, declined last
      const statusOrder = { pending: 0, completed: 1, declined: 2 };
      const aStatusOrder = statusOrder[a.status as keyof typeof statusOrder] ?? 3;
      const bStatusOrder = statusOrder[b.status as keyof typeof statusOrder] ?? 3;
      if (aStatusOrder !== bStatusOrder) return aStatusOrder - bStatusOrder;
      
      // PRIORITY 2: Within same status, sort by urgency level (red=0, yellow=1, green=2)
      const aUrgency = getUrgencyLevel(a);
      const bUrgency = getUrgencyLevel(b);
      if (aUrgency !== bUrgency) return aUrgency - bUrgency;
      
      // PRIORITY 3: Within same status and urgency, sort by date received (newest first)
      return new Date(b.dateReceived).getTime() - new Date(a.dateReceived).getTime();
    });

  // Check if there are any requests with red urgency indicators
  const hasRedUrgentRequests = requests?.some((request) => {
    if (request.status === "completed" || request.status === "declined") return false;
    
    const now = new Date();
    const receivedDate = new Date(request.dateReceived);
    
    if (request.timeLimitType === "urgent") {
      const hoursElapsed = (now.getTime() - receivedDate.getTime()) / (1000 * 60 * 60);
      const hoursRemaining = 8 - hoursElapsed;
      return hoursRemaining < 3; // RED zone
    } else {
      const daysElapsed = differenceInDays(now, receivedDate);
      const daysRemaining = 10 - daysElapsed;
      return daysRemaining < 3; // RED zone
    }
  }) || false;

  const stats = {
    total: requests?.length || 0,
    pending: requests?.filter((r) => r.status === "pending").length || 0,
    completed: requests?.filter((r) => r.status === "completed").length || 0,
    declined: requests?.filter((r) => r.status === "declined").length || 0,
    urgent: requests?.filter((r) => {
      const daysSinceReceived = differenceInDays(new Date(), new Date(r.dateReceived));
      return r.status === "pending" && daysSinceReceived > 3;
    }).length || 0,
  };

  if (authLoading || !user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-secondary/10 flex items-center justify-center">
        <div className="text-center">
          <div className="h-12 w-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/10">
      {/* Header */}
      <div className="bg-card border-b border-card-border">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img src={logoImage} alt="ENVOY Logo" className="h-12 w-12 object-contain" />
            <div>
              <h1 className="text-xl font-semibold text-foreground">ENVOY</h1>
              <p className="text-xs text-muted-foreground">Admin Dashboard</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm font-medium text-foreground">{user?.firstName} {user?.lastName}</p>
              <p className="text-xs text-muted-foreground">{user?.email}</p>
            </div>
            <Button
              variant="outline"
              onClick={() => window.location.href = "/api/logout"}
              className="rounded-full"
              data-testid="button-logout"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Card className="p-8 border border-card-border rounded-full aspect-square flex flex-col items-center justify-center text-center">
              <p className="text-base text-muted-foreground mb-2 font-semibold">Total</p>
              <p className="text-6xl font-bold font-mono text-foreground" data-testid="stat-total">{stats.total}</p>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
          >
            <Card className="p-8 border border-card-border rounded-full aspect-square flex flex-col items-center justify-center text-center">
              <p className="text-base text-muted-foreground mb-2 font-semibold">Pending</p>
              <p className="text-6xl font-bold font-mono text-chart-3" data-testid="stat-pending">{stats.pending}</p>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.2 }}
          >
            <Card className="p-8 border border-card-border rounded-full aspect-square flex flex-col items-center justify-center text-center">
              <p className="text-base text-muted-foreground mb-2 font-semibold">Completed</p>
              <p className="text-6xl font-bold font-mono text-chart-4" data-testid="stat-completed">{stats.completed}</p>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.3 }}
          >
            <Card className="p-8 border border-card-border rounded-full aspect-square flex flex-col items-center justify-center text-center">
              <p className="text-base text-muted-foreground mb-2 font-semibold">Declined</p>
              <p className="text-6xl font-bold font-mono text-orange-600" data-testid="stat-declined">{stats.declined}</p>
            </Card>
          </motion.div>
        </div>

        {/* Filters */}
        <div className="flex gap-2 mb-6 flex-wrap">
          <Button
            variant={filter === "all" ? "default" : "outline"}
            onClick={() => setFilter("all")}
            className="rounded-full"
            data-testid="filter-all"
          >
            All Requests
          </Button>
          <Button
            variant={filter === "pending" ? "default" : "outline"}
            onClick={() => setFilter("pending")}
            className="rounded-full"
            data-testid="filter-pending"
          >
            Pending
          </Button>
          <Button
            variant={filter === "completed" ? "default" : "outline"}
            onClick={() => setFilter("completed")}
            className="rounded-full"
            data-testid="filter-completed"
          >
            Completed
          </Button>
          <Button
            variant={filter === "declined" ? "default" : "outline"}
            onClick={() => setFilter("declined")}
            className="rounded-full"
            data-testid="filter-declined"
          >
            Declined
          </Button>
          <Button
            variant={filter === "urgent" ? "default" : "outline"}
            onClick={() => setFilter("urgent")}
            className="rounded-full"
            data-testid="filter-urgent"
          >
            Urgent
          </Button>
        </div>

        {/* Requests List */}
        {isLoading ? (
          <div className="text-center py-12">
            <div className="h-12 w-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading requests...</p>
          </div>
        ) : filteredRequests && filteredRequests.length === 0 ? (
          <div className="text-center py-16">
            <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-medium text-foreground mb-2">No Requests Found</h3>
            <p className="text-sm text-muted-foreground">
              {filter === "all"
                ? "No data access requests have been submitted yet."
                : `No ${filter} requests at this time.`}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {filteredRequests?.map((request, index) => (
                <RequestCard
                  key={request.id}
                  request={request}
                  index={index}
                  onUpdateStatus={(status) =>
                    updateStatusMutation.mutate({ id: request.id, status })
                  }
                  isUpdating={updateStatusMutation.isPending}
                  toast={toast}
                />
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}

interface RequestCardProps {
  request: RequestWithAttachments;
  index: number;
  onUpdateStatus: (status: string) => void;
  isUpdating: boolean;
  toast: ReturnType<typeof useToast>["toast"];
}

const RequestCard = forwardRef<HTMLDivElement, RequestCardProps>(function RequestCard({
  request,
  index,
  onUpdateStatus,
  isUpdating,
  toast,
}, ref) {
  const [, setLocation] = useLocation();
  const daysSinceReceived = differenceInDays(new Date(), new Date(request.dateReceived));
  const isUrgent = daysSinceReceived > 3;

  const handleCardClick = (e: React.MouseEvent) => {
    // Don't navigate if clicking on a button, link, or interactive element
    const target = e.target as HTMLElement;
    if (
      target.closest('button') ||
      target.closest('a') ||
      target.tagName === 'BUTTON' ||
      target.tagName === 'A'
    ) {
      return;
    }
    setLocation(`/request/${request.id}`);
  };

  const getStatusColor = () => {
    if (request.status === "completed") return "text-chart-4";
    if (isUrgent) return "text-chart-3";
    return "text-primary";
  };

  // Calculate urgency indicator color based on time remaining and deadline type
  const getUrgencyIndicatorColor = () => {
    // Don't show indicator for completed requests
    if (request.status === "completed") return null;

    const now = new Date();
    const receivedDate = new Date(request.dateReceived);
    
    if (request.timeLimitType === "urgent") {
      // Urgent: 8 hours deadline
      const hoursElapsed = (now.getTime() - receivedDate.getTime()) / (1000 * 60 * 60);
      const hoursRemaining = 8 - hoursElapsed;
      
      if (hoursRemaining >= 6) return "bg-green-400"; // GREEN: 8h → 6h remaining
      if (hoursRemaining >= 3) return "bg-yellow-400"; // YELLOW: 5h → 3h remaining
      return "bg-red-500"; // RED: 2h → 0h remaining
    } else {
      // Normal: 10 days deadline
      const daysElapsed = differenceInDays(now, receivedDate);
      const daysRemaining = 10 - daysElapsed;
      
      if (daysRemaining >= 6) return "bg-green-400"; // GREEN: 10 → 6 days remaining
      if (daysRemaining >= 3) return "bg-yellow-400"; // YELLOW: 5 → 3 days remaining
      return "bg-red-500"; // RED: 2 → 0 days remaining
    }
  };

  const urgencyColor = getUrgencyIndicatorColor();

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
    >
      <Card 
        className="p-6 border border-card-border hover:shadow-lg transition-all duration-300 cursor-pointer hover-elevate"
        onClick={handleCardClick}
        data-testid={`request-card-${request.id}`}
      >
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-lg font-medium text-foreground mb-1" data-testid={`request-org-${request.id}`}>
              {request.institutionName}
            </h3>
            <p className="text-sm text-muted-foreground">
              {request.contactFirstName} {request.contactLastName}
            </p>
            <p className="text-xs text-muted-foreground">{request.contactEmail}</p>
          </div>
          <Badge
            variant={request.status === "completed" ? "default" : request.status === "declined" ? "destructive" : "secondary"}
            className={request.status === "declined" ? "rounded-full bg-orange-600 hover:bg-orange-700 border-orange-700" : "rounded-full"}
            data-testid={`request-status-${request.id}`}
          >
            {request.status === "completed" ? (
              <>
                <CheckCircle2 className="h-3 w-3 mr-1" />
                Completed
              </>
            ) : request.status === "declined" ? (
              <>
                <XCircle className="h-3 w-3 mr-1" />
                Declined
              </>
            ) : (
              <>
                <Clock className="h-3 w-3 mr-1" />
                Pending
              </>
            )}
          </Badge>
        </div>

        <div className="space-y-3 mb-4">
          <div>
            <p className="text-xs text-muted-foreground mb-1">Product Name</p>
            <p className="text-sm text-foreground">{request.productName}</p>
          </div>

          <div>
            <p className="text-xs text-muted-foreground mb-1">Company Name</p>
            <p className="text-sm text-foreground">{request.companyName}</p>
          </div>

          <div>
            <p className="text-xs text-muted-foreground mb-1">Time Limit</p>
            <div className="flex items-center gap-2">
              <Badge 
                variant={request.timeLimitType === "urgent" ? "destructive" : "secondary"}
                className="rounded-full"
                data-testid={`request-time-limit-${request.id}`}
              >
                {request.timeLimitType === "urgent" ? "Urgent - 8 hours" : "Normal - 10 days"}
              </Badge>
              {urgencyColor && (
                <motion.div
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.4, delay: 0.2 }}
                  data-testid={`urgency-indicator-${request.id}`}
                >
                  <motion.div
                    className={`h-3 w-3 rounded-full ${urgencyColor} shadow-lg`}
                    animate={{
                      boxShadow: [
                        `0 0 8px ${urgencyColor === 'bg-green-400' ? 'rgba(74, 222, 128, 0.6)' : urgencyColor === 'bg-yellow-400' ? 'rgba(250, 204, 21, 0.6)' : 'rgba(239, 68, 68, 0.6)'}`,
                        `0 0 12px ${urgencyColor === 'bg-green-400' ? 'rgba(74, 222, 128, 0.8)' : urgencyColor === 'bg-yellow-400' ? 'rgba(250, 204, 21, 0.8)' : 'rgba(239, 68, 68, 0.8)'}`,
                        `0 0 8px ${urgencyColor === 'bg-green-400' ? 'rgba(74, 222, 128, 0.6)' : urgencyColor === 'bg-yellow-400' ? 'rgba(250, 204, 21, 0.6)' : 'rgba(239, 68, 68, 0.6)'}`
                      ]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />
                </motion.div>
              )}
            </div>
          </div>

          <div>
            <p className="text-xs text-muted-foreground mb-1">Customer Notification</p>
            <Badge 
              variant={request.informCustomer === "inform" ? "default" : "secondary"}
              className="rounded-full"
              data-testid={`request-inform-customer-${request.id}`}
            >
              {request.informCustomer === "inform" ? "Inform customer(s)" : "Do not inform customer(s)"}
            </Badge>
          </div>

          {request.dataHandoverMethod && (
            <div>
              <p className="text-xs text-muted-foreground mb-1">Data Handover Method</p>
              <Badge 
                variant="outline"
                className="rounded-full"
                data-testid={`request-handover-method-${request.id}`}
              >
                {request.dataHandoverMethod === "secure-email" && "Secure Email"}
                {request.dataHandoverMethod === "sftp" && "SFTP"}
                {request.dataHandoverMethod === "api" && "API Access"}
                {request.dataHandoverMethod === "encrypted-usb" && "Encrypted USB Drive"}
                {request.dataHandoverMethod === "secure-portal" && "Secure Web Portal"}
                {request.dataHandoverMethod === "other" && "Other"}
              </Badge>
            </div>
          )}

          <div>
            <p className="text-xs text-muted-foreground mb-1">Received</p>
            <div className="flex items-center gap-2">
              <p className={`text-sm font-mono font-medium ${getStatusColor()}`} data-testid={`request-date-${request.id}`}>
                {new Date(request.dateReceived).toLocaleDateString()}
              </p>
              {request.status === "pending" && (
                <span className="text-xs text-muted-foreground">
                  ({formatDistanceToNow(new Date(request.dateReceived), { addSuffix: true })})
                </span>
              )}
            </div>
          </div>

          {request.attachments.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground mb-2">Legal Documents ({request.attachments.length})</p>
              <div className="space-y-1">
                {request.attachments.map((file) => (
                  <a
                    key={file.id}
                    href={`/api/files/${file.id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-xs text-primary hover:underline"
                    data-testid={`attachment-${file.id}`}
                  >
                    <Download className="h-3 w-3" />
                    {file.originalName}
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>

        {request.status === "pending" && (
          <div className="space-y-2">
            <Button
              onClick={() => {
                toast({
                  title: "Legal Advice Request",
                  description: "This feature will be available soon to connect with legal advisors.",
                });
              }}
              className="w-full rounded-full bg-blue-600 hover:bg-blue-700 text-white border-blue-700"
              size="sm"
              data-testid={`button-legal-advice-${request.id}`}
            >
              <Scale className="h-4 w-4 mr-2" />
              Ask for Legal Advice
            </Button>
            <Button
              onClick={() => onUpdateStatus("completed")}
              disabled={isUpdating}
              className="w-full rounded-full"
              size="sm"
              data-testid={`button-complete-${request.id}`}
            >
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Mark as Completed
            </Button>
          </div>
        )}

        {(request.status === "completed" || request.status === "declined") && (
          <div className="space-y-2">
            <Button
              onClick={() => onUpdateStatus("pending")}
              disabled={isUpdating}
              variant="outline"
              className="w-full rounded-full"
              size="sm"
              data-testid={`button-reopen-${request.id}`}
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reopen Request
            </Button>
          </div>
        )}
      </Card>
    </motion.div>
  );
});
