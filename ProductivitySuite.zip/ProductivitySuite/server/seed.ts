import { db } from "./db";
import { dataRequests } from "@shared/schema";
import { addDays, subDays } from "date-fns";

async function seed() {
  console.log("Seeding database with sample data...");

  try {
    // Sample data access requests
    const sampleRequests = [
      {
        organizationName: "Federal Bureau of Investigation",
        contactPerson: "Agent Sarah Martinez",
        email: "s.martinez@fbi.gov",
        legalBasis: "court-order",
        dataTypeRequested: "User account data and activity logs for case #2024-CR-1234",
        deadline: addDays(new Date(), 5),
        additionalComments: "Urgent request related to ongoing criminal investigation. Court order attached.",
        status: "pending" as const,
      },
      {
        organizationName: "European Commission",
        contactPerson: "Dr. Hans Mueller",
        email: "hans.mueller@ec.europa.eu",
        legalBasis: "eu-evidence-directive",
        dataTypeRequested: "Cross-border transaction records for compliance audit",
        deadline: addDays(new Date(), 14),
        additionalComments: "Standard compliance request under EU e-Evidence Directive Article 5.",
        status: "pending" as const,
      },
      {
        organizationName: "Metropolitan Police Service",
        contactPerson: "Detective Inspector James Chen",
        email: "james.chen@met.police.uk",
        legalBasis: "investigation-warrant",
        dataTypeRequested: "IP address logs and connection timestamps for specified user ID",
        deadline: addDays(new Date(), 2),
        additionalComments: "Time-sensitive request. Investigation warrant #MPS-2024-0891 attached.",
        status: "pending" as const,
      },
      {
        organizationName: "German Federal Criminal Police Office",
        contactPerson: "Hauptkommissar Anna Schmidt",
        email: "anna.schmidt@bka.de",
        legalBasis: "eu-evidence-directive",
        dataTypeRequested: "Email communication records between specified parties",
        deadline: subDays(new Date(), 1),
        additionalComments: "Request submitted 8 days ago. Awaiting response.",
        status: "pending" as const,
      },
      {
        organizationName: "National Crime Agency",
        contactPerson: "Senior Officer Robert Thompson",
        email: "r.thompson@nca.gov.uk",
        legalBasis: "national-security",
        dataTypeRequested: "Financial transaction data for national security investigation",
        deadline: addDays(new Date(), 21),
        additionalComments: "Classified investigation. All documentation provided under seal.",
        status: "completed" as const,
      },
      {
        organizationName: "French Data Protection Authority",
        contactPerson: "Marie Dubois",
        email: "marie.dubois@cnil.fr",
        legalBasis: "gdpr-request",
        dataTypeRequested: "Personal data processing records for GDPR compliance audit",
        deadline: addDays(new Date(), 30),
        additionalComments: "Routine GDPR audit request. No urgency.",
        status: "completed" as const,
      },
    ];

    for (const request of sampleRequests) {
      await db.insert(dataRequests).values(request);
    }

    console.log(`✅ Successfully seeded ${sampleRequests.length} sample requests`);
    process.exit(0);
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    process.exit(1);
  }
}

seed();
