import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import multer from "multer";
import { z } from "zod";
import path from "path";
import { mkdir } from "fs/promises";
import { existsSync } from "fs";
import { randomUUID } from "crypto";
import { insertDataRequestSchema, insertInternalNoteSchema } from "@shared/schema";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), "uploads");

// Ensure upload directory exists
if (!existsSync(uploadDir)) {
  mkdir(uploadDir, { recursive: true }).catch(console.error);
}

const fileStorage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, uploadDir);
  },
  filename: (_req, file, cb) => {
    const uniqueName = `${randomUUID()}-${Date.now()}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  },
});

const upload = multer({
  storage: fileStorage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB max file size
  },
  fileFilter: (_req, file, cb) => {
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'image/jpeg',
      'image/jpg',
      'image/png',
    ];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, DOC, DOCX, JPG, and PNG files are allowed.'));
    }
  },
});

// Use the schema from shared/schema.ts (no need to redefine)

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Public route: Submit new data access request with file uploads
  app.post('/api/requests', upload.array('files', 10), async (req, res) => {
    try {
      // Parse and validate request data
      const data = JSON.parse(req.body.data);
      const validatedData = insertDataRequestSchema.parse(data);

      // Create the request
      const request = await storage.createRequest(validatedData);

      // Handle file attachments if any
      if (req.files && Array.isArray(req.files)) {
        for (const file of req.files) {
          await storage.createFileAttachment({
            requestId: request.id,
            fileName: file.filename,
            originalName: file.originalname,
            mimeType: file.mimetype,
            fileSize: file.size,
            filePath: file.path,
          });
        }
      }

      res.status(201).json(request);
    } catch (error) {
      console.error("Error creating request:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid request data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create request" });
      }
    }
  });

  // Protected route: Get all requests with attachments
  app.get('/api/requests', isAuthenticated, async (_req, res) => {
    try {
      const requests = await storage.getAllRequests();
      
      // Fetch attachments for each request
      const requestsWithAttachments = await Promise.all(
        requests.map(async (request) => {
          const attachments = await storage.getFileAttachmentsByRequestId(request.id);
          return { ...request, attachments };
        })
      );

      res.json(requestsWithAttachments);
    } catch (error) {
      console.error("Error fetching requests:", error);
      res.status(500).json({ message: "Failed to fetch requests" });
    }
  });

  // Protected route: Update request status
  app.patch('/api/requests/:id/status', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;

      if (!status || !['pending', 'completed', 'declined'].includes(status)) {
        res.status(400).json({ message: "Invalid status value" });
        return;
      }

      const updatedRequest = await storage.updateRequestStatus(id, status);

      if (!updatedRequest) {
        res.status(404).json({ message: "Request not found" });
        return;
      }

      res.json(updatedRequest);
    } catch (error) {
      console.error("Error updating request status:", error);
      res.status(500).json({ message: "Failed to update request status" });
    }
  });

  // Public route: Download file attachment
  app.get('/api/files/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const attachment = await storage.getFileAttachmentById(id);

      if (!attachment) {
        res.status(404).json({ message: "File not found" });
        return;
      }

      res.download(attachment.filePath, attachment.originalName);
    } catch (error) {
      console.error("Error downloading file:", error);
      res.status(500).json({ message: "Failed to download file" });
    }
  });

  // Protected route: Get notes for a request
  app.get('/api/requests/:id/notes', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const notes = await storage.getNotesByRequestId(id);
      res.json(notes);
    } catch (error) {
      console.error("Error fetching notes:", error);
      res.status(500).json({ message: "Failed to fetch notes" });
    }
  });

  // Protected route: Add a note to a request
  app.post('/api/requests/:id/notes', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Get user information for initials
      const user = await storage.getUser(userId);
      if (!user) {
        res.status(404).json({ message: "User not found" });
        return;
      }

      // Generate initials from user's first and last name
      const initials = `${user.firstName?.[0] || ''}${user.lastName?.[0] || ''}`.toUpperCase() || 'UN';

      const noteData = {
        requestId: id,
        userId: userId,
        userInitials: initials,
        content: req.body.content,
      };

      const validatedData = insertInternalNoteSchema.parse(noteData);
      const note = await storage.createNote(validatedData);
      
      res.status(201).json(note);
    } catch (error) {
      console.error("Error creating note:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid note data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create note" });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
