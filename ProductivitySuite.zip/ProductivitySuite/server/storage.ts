import {
  users,
  dataRequests,
  fileAttachments,
  internalNotes,
  type User,
  type UpsertUser,
  type DataRequest,
  type InsertDataRequest,
  type FileAttachment,
  type InsertFileAttachment,
  type InternalNote,
  type InsertInternalNote,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User operations - Required for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Request operations
  createRequest(request: InsertDataRequest): Promise<DataRequest>;
  getAllRequests(): Promise<DataRequest[]>;
  getRequestById(id: string): Promise<DataRequest | undefined>;
  updateRequestStatus(id: string, status: string): Promise<DataRequest | undefined>;

  // File attachment operations
  createFileAttachment(attachment: InsertFileAttachment): Promise<FileAttachment>;
  getFileAttachmentsByRequestId(requestId: string): Promise<FileAttachment[]>;
  getFileAttachmentById(id: string): Promise<FileAttachment | undefined>;

  // Internal notes operations
  createNote(note: InsertInternalNote): Promise<InternalNote>;
  getNotesByRequestId(requestId: string): Promise<InternalNote[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations - Required for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    // First try to find existing user by email
    const [existingUser] = await db
      .select()
      .from(users)
      .where(eq(users.email, userData.email!));

    if (existingUser) {
      // Update existing user
      const [updated] = await db
        .update(users)
        .set({
          ...userData,
          updatedAt: new Date(),
        })
        .where(eq(users.email, userData.email!))
        .returning();
      return updated;
    }

    // Insert new user
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    return user;
  }

  // Request operations
  async createRequest(requestData: InsertDataRequest): Promise<DataRequest> {
    const [request] = await db
      .insert(dataRequests)
      .values(requestData)
      .returning();
    return request;
  }

  async getAllRequests(): Promise<DataRequest[]> {
    return await db.select().from(dataRequests).orderBy(desc(dataRequests.dateReceived));
  }

  async getRequestById(id: string): Promise<DataRequest | undefined> {
    const [request] = await db.select().from(dataRequests).where(eq(dataRequests.id, id));
    return request;
  }

  async updateRequestStatus(id: string, status: string): Promise<DataRequest | undefined> {
    const updateData: any = { 
      status, 
      updatedAt: new Date() 
    };
    
    // When marking as complete, set completedAt timestamp
    if (status === 'completed') {
      updateData.completedAt = new Date();
    }
    
    // When reopening (marking as pending), clear completedAt
    if (status === 'pending') {
      updateData.completedAt = null;
    }
    
    const [request] = await db
      .update(dataRequests)
      .set(updateData)
      .where(eq(dataRequests.id, id))
      .returning();
    return request;
  }

  // File attachment operations
  async createFileAttachment(attachmentData: InsertFileAttachment): Promise<FileAttachment> {
    const [attachment] = await db
      .insert(fileAttachments)
      .values(attachmentData)
      .returning();
    return attachment;
  }

  async getFileAttachmentsByRequestId(requestId: string): Promise<FileAttachment[]> {
    return await db.select().from(fileAttachments).where(eq(fileAttachments.requestId, requestId));
  }

  async getFileAttachmentById(id: string): Promise<FileAttachment | undefined> {
    const [attachment] = await db.select().from(fileAttachments).where(eq(fileAttachments.id, id));
    return attachment;
  }

  // Internal notes operations
  async createNote(noteData: InsertInternalNote): Promise<InternalNote> {
    const [note] = await db
      .insert(internalNotes)
      .values(noteData)
      .returning();
    return note;
  }

  async getNotesByRequestId(requestId: string): Promise<InternalNote[]> {
    return await db
      .select()
      .from(internalNotes)
      .where(eq(internalNotes.requestId, requestId))
      .orderBy(desc(internalNotes.createdAt));
  }
}

export const storage = new DatabaseStorage();
