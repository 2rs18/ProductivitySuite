import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table - Required for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - Required for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Data access requests table
export const dataRequests = pgTable("data_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  productName: varchar("product_name", { length: 255 }).notNull(),
  companyName: varchar("company_name", { length: 255 }).notNull(),
  institutionName: varchar("institution_name", { length: 255 }).notNull(),
  contactFirstName: varchar("contact_first_name", { length: 255 }).notNull(),
  contactLastName: varchar("contact_last_name", { length: 255 }).notNull(),
  contactEmail: varchar("contact_email", { length: 255 }).notNull(),
  contactPhone: varchar("contact_phone", { length: 50 }).notNull(),
  reasonForRequest: text("reason_for_request").notNull(),
  otherChannels: text("other_channels"),
  reasonNotInformingCustomer: text("reason_not_informing_customer"),
  dataHandoverMethod: varchar("data_handover_method", { length: 100 }),
  informCustomer: varchar("inform_customer", { length: 50 }).notNull(),
  timeLimitType: varchar("time_limit_type", { length: 50 }).notNull().default("normal"),
  status: varchar("status", { length: 20 }).notNull().default("pending"),
  dateReceived: timestamp("date_received").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const dataRequestsRelations = relations(dataRequests, ({ many }) => ({
  attachments: many(fileAttachments),
  notes: many(internalNotes),
}));

export const insertDataRequestSchema = createInsertSchema(dataRequests).omit({
  id: true,
  status: true,
  dateReceived: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  productName: z.string().min(1, "Product name is required"),
  companyName: z.string().min(1, "Company name is required"),
  institutionName: z.string().min(1, "Institution name is required"),
  contactFirstName: z.string().min(1, "First name is required"),
  contactLastName: z.string().min(1, "Last name is required"),
  contactEmail: z.string().email("Valid email is required"),
  contactPhone: z.string().min(1, "Phone number is required"),
  reasonForRequest: z.string().min(1, "Reason for request is required"),
  otherChannels: z.string().min(1, "Other channels information is required"),
  reasonNotInformingCustomer: z.string().min(1, "Reason for not informing customer is required"),
  dataHandoverMethod: z.string().min(1, "Data handover method is required"),
  informCustomer: z.string().min(1, "Please select whether to inform the customer"),
  timeLimitType: z.string().min(1, "Time limit is required"),
});

export type InsertDataRequest = z.infer<typeof insertDataRequestSchema>;
export type DataRequest = typeof dataRequests.$inferSelect;

// File attachments table
export const fileAttachments = pgTable("file_attachments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  requestId: varchar("request_id").notNull().references(() => dataRequests.id, { onDelete: 'cascade' }),
  fileName: varchar("file_name", { length: 255 }).notNull(),
  originalName: varchar("original_name", { length: 255 }).notNull(),
  mimeType: varchar("mime_type", { length: 100 }).notNull(),
  fileSize: integer("file_size").notNull(),
  filePath: varchar("file_path", { length: 500 }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const fileAttachmentsRelations = relations(fileAttachments, ({ one }) => ({
  request: one(dataRequests, {
    fields: [fileAttachments.requestId],
    references: [dataRequests.id],
  }),
}));

export type FileAttachment = typeof fileAttachments.$inferSelect;
export type InsertFileAttachment = typeof fileAttachments.$inferInsert;

// Internal notes table
export const internalNotes = pgTable("internal_notes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  requestId: varchar("request_id").notNull().references(() => dataRequests.id, { onDelete: 'cascade' }),
  userId: varchar("user_id").notNull().references(() => users.id),
  userInitials: varchar("user_initials", { length: 10 }).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const internalNotesRelations = relations(internalNotes, ({ one }) => ({
  request: one(dataRequests, {
    fields: [internalNotes.requestId],
    references: [dataRequests.id],
  }),
  user: one(users, {
    fields: [internalNotes.userId],
    references: [users.id],
  }),
}));

export const insertInternalNoteSchema = createInsertSchema(internalNotes).omit({
  id: true,
  createdAt: true,
}).extend({
  requestId: z.string().min(1, "Request ID is required"),
  userId: z.string().min(1, "User ID is required"),
  userInitials: z.string().min(1, "User initials are required"),
  content: z.string().min(1, "Note content is required"),
});

export type InsertInternalNote = z.infer<typeof insertInternalNoteSchema>;
export type InternalNote = typeof internalNotes.$inferSelect;
